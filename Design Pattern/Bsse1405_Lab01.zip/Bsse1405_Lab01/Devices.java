abstract public class Devices {
     String deviceModel;
    public abstract void powerOn();
    public abstract void powerOff();
}
